To run the code:
python HW4-112871754/kmeans.py --dataset ./Breast_cancer_data.csv

By default distance metric is Euclidean.
To run with Manhattan disatnce:
python HW4-112871754/kmeans.py --dataset ./Breast_cancer_data.csv --distance Manhattan