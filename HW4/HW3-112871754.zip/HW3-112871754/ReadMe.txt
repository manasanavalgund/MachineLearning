To run:
python knn.py --dataset [dataset_lcoation] --k [k value for knn]

Example:
python knn.py --dataset ./Breast_cancer_data.csv --k 19

Output:
Accuracy and error rate are printed on console and output redirected to output.txt